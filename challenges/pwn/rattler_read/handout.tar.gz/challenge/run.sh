#!/bin/sh

cd /home/user
/usr/local/bin/python3 -u main.py
